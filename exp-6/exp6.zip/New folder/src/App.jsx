import { useState } from 'react'
import reactLogo from './assets/react.svg'
import viteLogo from '/vite.svg'
import './App.css'
import Form from "./components/Form";

function App() {
  return (
    <div>
      <h2>Experiment 6: Form Handling & Validation done by uid-23BDA70048</h2>
      <Form />
    </div>
  );
}

export default App;

