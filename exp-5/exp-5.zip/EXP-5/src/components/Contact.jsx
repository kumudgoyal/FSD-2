export default function Contact() {
  return (
    <div>
      <h3>Contact Component</h3>
      <p>This component is loaded lazily.</p>
    </div>
  );
}
