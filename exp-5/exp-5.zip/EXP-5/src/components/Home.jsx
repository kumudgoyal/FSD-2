export default function Home() {
  return (
    <div>
      <h3>Home Component</h3>
      <p>This component is loaded lazily.</p>
    </div>
  );
}
